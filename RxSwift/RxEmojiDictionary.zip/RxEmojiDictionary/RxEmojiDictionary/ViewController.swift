//
//  ViewController.swift
//  RxEmojiDictionary
//
//  Created by Carlos Alberto Savi on 05/04/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

